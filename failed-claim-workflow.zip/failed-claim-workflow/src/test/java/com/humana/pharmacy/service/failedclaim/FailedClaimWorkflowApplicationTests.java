package com.humana.pharmacy.service.failedclaim;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FailedClaimWorkflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
