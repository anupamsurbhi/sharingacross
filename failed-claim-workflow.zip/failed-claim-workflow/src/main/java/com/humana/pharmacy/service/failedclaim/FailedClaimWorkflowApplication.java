package com.humana.pharmacy.service.failedclaim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FailedClaimWorkflowApplication {

	public static void main(String[] args) {
		SpringApplication.run(FailedClaimWorkflowApplication.class, args);
	}

}
